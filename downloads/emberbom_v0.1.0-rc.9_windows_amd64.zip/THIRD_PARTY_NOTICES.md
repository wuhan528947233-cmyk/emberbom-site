# EmberBOM third-party notices

This file records software that is compiled into the EmberBOM CLI and software
that is present only in the public STM32 benchmark fixture. Third-party license
terms apply independently of the EmberBOM proprietary notice.

## Runtime dependencies included in the CLI

| Component | Pinned version | License | Upstream |
|---|---:|---|---|
| CycloneDX Go | 0.9.3 | Apache License 2.0 | <https://github.com/CycloneDX/cyclonedx-go> |
| YAML v3 | 3.0.4 | MIT and Apache License 2.0; see the upstream file-level terms | <https://github.com/yaml/go-yaml> |

Every EmberBOM release archive includes the exact `LICENSE` file obtained from
each pinned Go module under `LICENSES/`. Those copies, rather than this summary,
are the authoritative license terms for the bundled dependency versions.

## Fixture-only dependencies

The following repositories are pinned Git submodules used only to build and
test `fixtures/stm32-cmake`. They are not compiled into the EmberBOM CLI:

| Component | Fixture version | Upstream license location |
|---|---:|---|
| FreeRTOS-Kernel | 10.6.1 | `fixtures/stm32-cmake/vendor/FreeRTOS-Kernel/LICENSE.md` (MIT) |
| Mbed TLS | 3.5.1 | `fixtures/stm32-cmake/vendor/mbedtls/LICENSE` (Apache-2.0 OR GPL-2.0-or-later) |

The reduced FatFS-shaped source specimen and `libvendor.a` specimen in the
fixture are original EmberBOM test material. They do not copy upstream FatFS or
vendor library implementation code.

This inventory is a factual engineering record, not legal advice or a
certification of license compliance. Re-check the pinned versions and their
license files before a commercial release.
