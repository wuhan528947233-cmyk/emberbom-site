# EmberBOM security policy

## Supported versions

Only the newest EmberBOM release listed on the repository's Releases page is
supported. Earlier release candidates should be treated as unsupported once a
replacement is published.

## Report a vulnerability privately

Do not open a public GitHub issue containing vulnerability details, project
information, logs, scan output, SBOM content, paths, filenames, hashes, or
screenshots.

During the private Gate B pilot, report a suspected EmberBOM vulnerability
through the private contact channel contained in the trial invitation. Send
only the EmberBOM version, operating system, affected command, structure error
code if present, and a description written without customer project details.

If this repository later becomes public and GitHub private vulnerability
reporting is enabled, use **Security and quality → Report a vulnerability**.
Do not place vulnerability details in a public issue merely to request help.

Reports about component identification accuracy, installation failures, or
pilot feedback that do not describe a security vulnerability should use
the [pilot and safe-feedback guide](https://github.com/wuhan528947233-cmyk/EmberBOM/blob/main/docs/07-pilot-and-feedback.md).

## Scope

Security reports may cover the EmberBOM CLI, release packaging, local file
handling, unintended network access, or disclosure of scanned project data.
Vulnerabilities in FreeRTOS, Mbed TLS, GNU Arm, CMake, or projects scanned by
EmberBOM must be reported to their respective maintainers.
